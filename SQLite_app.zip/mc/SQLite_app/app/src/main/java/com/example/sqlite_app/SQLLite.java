package com.example.sqlite_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLLite extends SQLiteOpenHelper{
    public SQLLite(Context mainActivity){
        super(mainActivity, "DBASE",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table emp(ENAME TEXT,ECONTACT TEXT,EADDRESS TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists emp");
        onCreate(db);
    }

    public boolean insertData(String NAME,String CONTACT,String ADDRESS){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ENAME",NAME);
        contentValues.put("ECONTACT",CONTACT);
        contentValues.put("EADDRESS",ADDRESS);
        return true;
    }
}
